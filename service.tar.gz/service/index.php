<?php
echo "This is the test page";
echo ".dfjs ".$_GET['type']." \n";
echo ".dfjs ".$_GET['root']." \n";
echo "<br>";
echo phpinfo();
?>
